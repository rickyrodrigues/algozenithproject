(function() {
    let reviewSlides = document.querySelectorAll('.review-slide');

    // Set the current slide to the first slide
    let currentSlide = reviewSlides[0];

    // Add a click event listener to each slide
    reviewSlides.forEach(slide => {
        slide.addEventListener('click', function() {
            // Show the clicked slide
            currentSlide.classList.remove('active');
            $(this).addClass('active');

            // Set the current slide to the clicked slide
            currentSlide = this;
        });
    });

    // Add a swipe event listener to the carousel
    document.querySelector('.review-carousel').addEventListener('swipeleft', function() {
        // Show the next slide
        currentSlide.classList.remove('active');
        reviewSlides[reviewSlides.indexOf(currentSlide) + 1].classList.add('active');

        // Set the current slide to the next slide
        currentSlide = reviewSlides[reviewSlides.indexOf(currentSlide) + 1];
    });

    document.querySelector('.review-carousel').addEventListener('swiperight', function() {
        // Show the previous slide
        currentSlide.classList.remove('active');
        reviewSlides[reviewSlides.indexOf(currentSlide) - 1].classList.add('active');

        // Set the current slide to the previous slide
        currentSlide = reviewSlides[reviewSlides.indexOf(currentSlide) - 1];
    });
})();
